package Arquitecturaclean.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArquitecturacleanApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArquitecturacleanApplication.class, args);
	}

}
