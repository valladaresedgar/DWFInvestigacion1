package Arquitecturaclean.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArquitecturacleanApplicationTests {

	@Test
	void contextLoads() {
	}

}
